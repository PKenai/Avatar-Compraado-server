
function onStepIn(cid, item, position, fromPosition)
	local newpos = {x=558, y=315, z=9}
	if fromPosition.z > position.z then 
		doTeleportThing(cid, newpos) 
	end
  return true
end
